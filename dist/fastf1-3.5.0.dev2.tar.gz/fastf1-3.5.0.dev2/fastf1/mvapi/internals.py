from fastf1.logger import get_logger


_logger = get_logger('mvapi')
