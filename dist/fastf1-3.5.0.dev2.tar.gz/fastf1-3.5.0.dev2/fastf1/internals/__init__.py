from fastf1.logger import get_logger


internals_logger = get_logger(__name__)
